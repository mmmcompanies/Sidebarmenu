//
//  NextPage.h
//  MobilePoojan
//
//  Created by Techno Softwares on 26/12/16.
//  Copyright © 2016 Techno Softwares. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextPage : UIViewController

@end
