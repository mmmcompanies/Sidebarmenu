//
//  HomePageView.m
//  MobilePoojan
//
//  Created by Techno Softwares on 23/12/16.
//  Copyright © 2016 Techno Softwares. All rights reserved.
//
#import "MenuView.h"
#import "HomePageView.h"

@interface HomePageView ()

@end

@implementation HomePageView

- (void)viewDidLoad {
    [super viewDidLoad];
    
    SubView = [MenuView newMenuView];
    SubView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width, 70.0, [UIScreen mainScreen].bounds.size.width/2, [UIScreen mainScreen].bounds.size.height - 100);
    SubView.hidden = true;
    [self.view addSubview:SubView];
    
    SubviewAdd = YES;
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(([UIScreen mainScreen].bounds.size.width / 2) + 35, 68.0)];
    [path addLineToPoint:CGPointMake(([UIScreen mainScreen].bounds.size.width / 2) - 35, 72.0 + _fastival_view.frame.size.height )];
    
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = [path CGPath];
    shapeLayer.strokeColor = [[UIColor colorWithRed:177.0/255.0 green:49.0/255.0 blue:79.0/255.0 alpha:1.0] CGColor];
    shapeLayer.lineWidth = 3.0;
    shapeLayer.fillColor = [[UIColor clearColor] CGColor];
    
    [self.view.layer addSublayer:shapeLayer];
    
    
    UIBezierPath *path1 = [UIBezierPath bezierPath];
    [path1 moveToPoint:CGPointMake(([UIScreen mainScreen].bounds.size.width / 2) - 35, 320.0)];
    [path1 addLineToPoint:CGPointMake(([UIScreen mainScreen].bounds.size.width / 2) + 35, 322 + _upcoming_view.frame.size.height )];
    CAShapeLayer *shapeLayer1 = [CAShapeLayer layer];
    shapeLayer1.path = [path1 CGPath];
    shapeLayer1.strokeColor = [[UIColor colorWithRed:177.0/255.0 green:49.0/255.0 blue:79.0/255.0 alpha:1.0] CGColor];
    shapeLayer1.lineWidth = 3.0;
    shapeLayer1.fillColor = [[UIColor clearColor] CGColor];
    
     [self.view.layer addSublayer:shapeLayer1];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)btn_festivals_clicked:(id)sender {
   
     [self performSegueWithIdentifier:@"nextpage" sender:self];
}

-(IBAction)btnSideMenu:(id)sender
{
    
    if(SubviewAdd)
    {
        [[SubView superview] bringSubviewToFront:SubView];
        SubviewAdd = NO;
        SubView.hidden = false;
//         SubView.btn_demo.hidden = true;
//        SubView.transform = CGAffineTransformMakeScale(0.1, 1.0);
        [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
//            SubView.transform = CGAffineTransformIdentity;
            SubView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width/2, 70.0, [UIScreen mainScreen].bounds.size.width/2, [UIScreen mainScreen].bounds.size.height - 120);
//            SubView.btn_demo.hidden = false;
            
        } completion:^(BOOL finished) {
           
            
        }];
    }
    
    else
    {
        [UIView animateWithDuration:0.5 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            
//            SubView.transform = CGAffineTransformMakeScale(0.001, 1.0);
            SubView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width, 70.0, [UIScreen mainScreen].bounds.size.width/2, [UIScreen mainScreen].bounds.size.height - 120);
            
        } completion:^(BOOL finished) {
            
            SubviewAdd = YES;
            SubView.hidden = true;
            
        }];
    }
}

@end
