//
//  HomePageView.h
//  MobilePoojan
//
//  Created by Techno Softwares on 23/12/16.
//  Copyright © 2016 Techno Softwares. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomePageView : UIViewController
{
    bool SubviewAdd;
    MenuView *SubView;
}
@property (strong, nonatomic) IBOutlet UIView *fastival_view;
@property (strong, nonatomic) IBOutlet UIView *upcoming_view;

@end
