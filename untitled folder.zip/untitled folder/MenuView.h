//
//  MenuView.h
//  MobilePoojan
//
//  Created by Techno Softwares on 26/12/16.
//  Copyright © 2016 Techno Softwares. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuView : UIView
@property (strong, nonatomic) IBOutlet UIButton *btn_demo;
- (IBAction)Btn_demo_clicked:(id)sender;
+ (id) newMenuView;
@end
