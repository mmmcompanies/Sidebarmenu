//
//  MenuView.m
//  MobilePoojan
//
//  Created by Techno Softwares on 26/12/16.
//  Copyright © 2016 Techno Softwares. All rights reserved.
//

#import "MenuView.h"

@implementation MenuView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
+ (id) newMenuView
{
    UINib *nib = [UINib nibWithNibName:@"MenuView" bundle:nil];
    NSArray *nibArray = [nib instantiateWithOwner:self options:nil];
    MenuView *me = [nibArray objectAtIndex: 0];
    return me;
}

- (IBAction)Btn_demo_clicked:(id)sender {
    
    NSLog(@"hello demo ");
}
@end
