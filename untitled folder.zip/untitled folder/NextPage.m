//
//  NextPage.m
//  MobilePoojan
//
//  Created by Techno Softwares on 26/12/16.
//  Copyright © 2016 Techno Softwares. All rights reserved.
//
#import "SBSliderView.h"
#import "NextPage.h"
#define _AUTO_SCROLL_ENABLED 1

@interface NextPage () {
    NSMutableArray *imagesArray;
    SBSliderView *slider;
}


@end

@implementation NextPage

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    imagesArray = [[NSMutableArray alloc] initWithObjects:@"Welcome.jpg", @"ganesh.jpeg", @"download.jpeg", @"happydiwali.png", nil];
    
    slider = [[[NSBundle mainBundle] loadNibNamed:@"SBSliderView" owner:self options:nil] firstObject];
   
    [self.view addSubview:slider];
    
    [slider createSliderWithImages:imagesArray WithAutoScroll:_AUTO_SCROLL_ENABLED inView:self.view hight:400.0];
    
    slider.frame = CGRectMake(0, 70.0, [UIScreen mainScreen].bounds.size.width, 400.0);
   

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
